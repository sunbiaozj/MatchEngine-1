package com.scb;

/**
 * @author DAO TUAN ANH (DENNIS).
 * @created on 14/7/16.
 */
public enum MatchType {
    STRONG, WEAK, BREAK;

}
